'use client'

import { ProductType } from '@/lib/product-type/product'
import { useState } from 'react'
import ProductDetailComponent from './ProductDetailComponent'


export default function CardProductComponent({
  id,
  thumbnail,
  name,
  description,
  priceOut,
}: ProductType & { id: string }) {
  const [showDetail, setShowDetail] = useState(false)

  return (
    <>
      <div
        className="max-w-sm rounded-md overflow-hidden shadow-md hover:shadow-lg cursor-pointer transition-shadow"
        onClick={() => setShowDetail(true)}
      >
        <div className="relative">
          <img className="w-full h-48 object-cover" src={thumbnail} alt={name} />
          <div className="absolute top-0 right-0 bg-red-500 text-white px-2 py-1 m-2 rounded-md text-sm font-medium">
            SALE
          </div>
        </div>
        <div className="p-4">
          <h3 className="text-lg font-medium mb-1">{name}</h3>
          <p className="text-gray-500 text-sm mb-3 line-clamp-2">{description}</p>
          <span className="font-bold text-lg">{priceOut}</span>
        </div>
      </div>

      {showDetail && (
        <ProductDetailComponent
          thumbnail={thumbnail}
          name={name}
          description={description}
          priceOut={priceOut}
          onClose={() => setShowDetail(false)}
        />
      )}
    </>
  )
}
