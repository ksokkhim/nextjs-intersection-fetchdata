'use client'

import { ProductType } from '@/lib/product-type/product'
import { Modal } from 'flowbite-react'

interface ProductDetailProps extends ProductType {
  onClose: () => void
}

export default function ProductDetailComponent({
  thumbnail,
  name,
  description,
  priceOut,
  onClose,
}: ProductDetailProps) {
  return (
    <Modal show={true} size="4xl" onClose={onClose} popup dismissible>
      <Modal.Header />
      <Modal.Body>
        <div className="max-w-2xl mx-auto rounded-md overflow-hidden">
          <div className="relative">
            <img
              className="w-full h-72 object-cover"
              src={thumbnail}
              alt={name}
            />
            <div className="absolute top-0 right-0 bg-red-500 text-white px-2 py-1 m-2 rounded-md text-sm font-medium">
              SALE
            </div>
          </div>
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-3">{name}</h3>
            <p className="text-gray-600 text-sm mb-6">{description}</p>
            <div className="flex items-center justify-between">
              <span className="font-bold text-2xl">{priceOut}</span>
              <div className="flex gap-3">
                <button
                  className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded"
                  onClick={() => alert('Added to cart!')}
                >
                  Add to Cart
                </button>
                <button
                  className="border border-gray-300 hover:bg-gray-100 font-bold py-2 px-4 rounded"
                  onClick={onClose}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  )
}
